HHA DAILY — MARYLAND REFERRAL REPORT — v0.8.1
============================================

WHAT CHANGED
- The pull no longer stalls when HHAeXchange keeps its internal “loading”
  flag on after the pages are already on screen. A visible wait overlay is
  what holds Excel back. Page count has to sit still briefly before export,
  so you don’t get an empty or half-written file.
- Stopped hammering every frame several times a second. That polling was
  slowing the report viewer itself, which made the pull feel stuck.
- Excel downloads are recognized even when Chrome has not named them .xlsx
  yet (Report Viewer .axd streams, zip/octet-stream). The save name is
  applied immediately instead of waiting on storage, which left files
  spinning in the download shelf.
- A report window left open from an earlier pull is used when it actually
  navigates to today’s report. It is still ignored if it just sits there.
- Today’s dates are written and View Report is clicked in the same step so
  the report is not run on the previous dates.
- A slow report is no longer failed at 60 seconds while it is still drawing.
  The run waits up to 10 minutes.

INSTALL OR UPDATE
1. Extract this ZIP to a permanent location.
2. Chrome: open chrome://extensions (Edge: edge://extensions).
3. If you already loaded the older extension from a permanent folder, replace
   that folder's files with these, then click Reload on its extension card.
   This preserves its settings and keeps the same extension ID.
4. For a fresh install, turn on Developer mode, click Load unpacked, and
   select hhaexchange-auto-report (the folder containing manifest.json).
   Disable the older copy if loading from a different folder so only one runs.
5. Refresh existing HHAeXchange tabs so they receive the updated page script.
6. Pin the extension and sign in to Maryland HHAeXchange yourself.

AUTOMATIC SAVING AND NOTIFICATIONS
- Open the extension's Automation tab. Save destination defaults to
  HHA Reports, a subfolder of your browser's configured Downloads directory.
- Nested subfolders are supported. Leave the field empty for Downloads itself.
  Absolute paths are not supported by Chrome's download filename API.
- Use Open download settings and turn OFF "Ask where to save each file
  before downloading" for unattended native HHA exports. This is a browser
  preference and affects other downloads too; the extension does not change it.
- Keep "Notify me when it's saved" enabled. Chrome and Windows notification
  settings / Do Not Disturb can suppress desktop notifications. The Activity
  view and extension badge still show the outcome.
- Completion is reported only after Chrome says the file finished. Click the
  notification or the arrow beside a saved report to show the file in its folder.

DAILY USE
Click Pull today's report from any tab after signing in. The extension opens
Referral Patients By Status, sets Received From and Received To to today,
uses View Report, waits for the viewer, then exports Excel. Existing filters
retain the original extension's behavior; Generate Report is not used.

Weekday auto-pull defaults to 4:50 PM, Monday–Friday, using your computer's
local time. Change it in Automation. Existing schedule preferences survive an
in-place update. Chrome must be running, the computer awake, and the portal
session signed in. A missed-pull reminder appears when Chrome next starts.
The viewer may come to the foreground to allow the portal to render reliably.

Stop prevents further automation. A download already handed to Chrome may
continue; cancel that file from Chrome's Downloads page if needed.

PRIVACY AND PERMISSIONS
No new permissions beyond v0.7.0. No analytics, external fonts, remote scripts,
or upload service. Login and MFA remain manual. Report files stay on your
computer. Local extension storage holds preferences, status, download IDs,
filenames and recent run metadata; it does not copy report contents.

VERIFICATION AND LIMITS
14 automated regression tests passed, covering readiness fallback, frame
selection, download attribution, restart recovery, export ownership, folder
validation, history/notifications, and stop/retry behavior. The popup was
visually and interactively checked using a local demo with synthetic data.
A real authenticated HHAeXchange pull has NOT been verified in this environment.
The extension removes avoidable waits; it cannot accelerate HHA server-side
report generation. If a pull still fails, its status message and Activity entry
identify the stage. Allow the View Report popup if your browser blocks it.

Developer source includes tests and a local UI fixture outside this packaged
extension folder. Run tests with: node --test tests/regression.test.cjs
