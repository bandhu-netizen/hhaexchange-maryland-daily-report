/* global chrome */
importScripts("config.js");

const RUN_KEY = "hhaActiveRun";
const LAST_KEY = "hhaLastRun";
const HISTORY_KEY = "hhaRunHistory";
const RENAME_KEY = "hhaPendingRename";
const SETTINGS_KEY = "hhaSettings";
const PORTAL_KEY = "hhaLastPortalUrl";
const ALARM_NAME = "hhaDailyPull";
const WATCH_ALARM = "hhaRunWatch";
const DEFAULT_PORTAL = "https://app.hhaexchange.com/";

const DEFAULT_SETTINGS = {
  scheduleEnabled: true,
  hour: 16,
  minute: 50,
  weekdaysOnly: true,
  downloadFolder: "HHA Reports",
  notifyOnComplete: true
};

let activeRun = null;
const watchedDownloads = new Map();
const ports = new Set();
let downloadWatchdog = null;
let heartbeatTimer = null;
let renameState = { enabled: false, base: "", startedAt: 0 };
let exportRetryCount = 0;
let acceptedDownloadId = null;
const exportSentTabs = new Set();
let runSucceeded = false;
let startingRun = false;
let startupGeneration = 0;
let finishingRun = false;

function stopHeartbeat() {
  if (heartbeatTimer) {
    clearInterval(heartbeatTimer);
    heartbeatTimer = null;
  }
}

function startHeartbeat() {
  stopHeartbeat();
  heartbeatTimer = setInterval(async () => {
    if (!activeRun) {
      stopHeartbeat();
      return;
    }
    const elapsed = Math.round((Date.now() - activeRun.startedAt) / 1000);
    if (activeRun.stage === "waitingViewer") {
      await log(`View Report window is open — you should see the report loading (${elapsed}s). Excel downloads from there, not Generate Report.`);
    } else if (activeRun.stage === "exporting") {
      await log(`Report view is on screen. Exporting Excel (${elapsed}s)…`);
    }
  }, 5000);
}

function pad(n) {
  return String(n).padStart(2, "0");
}

function filenameDate(date = new Date()) {
  return `${pad(date.getMonth() + 1)}-${pad(date.getDate())}-${date.getFullYear()}`;
}

function reportFilename(ext = "xlsx") {
  return `Report of ${filenameDate()}.${ext}`;
}

function isHhaUrl(url = "") {
  try {
    const u = new URL(url);
    return u.hostname === "hhaexchange.com" || u.hostname.endsWith(".hhaexchange.com");
  } catch (_) {
    return false;
  }
}

function looksLikeLoginUrl(url = "") {
  return /login|signin|sign-in|sso|auth/i.test(url);
}

function looksLikeViewerUrl(url = "") {
  if (/UserDataXML=/i.test(url)) return true;
  if (/ReportViewerWebControl|Reserved\.ReportViewer/i.test(url)) return true;
  if (/\/ReportViewer/i.test(url)) return true;
  if (/ViewReport|ShowReport|ReportRender|Reserved\.Report/i.test(url)) return true;
  if (/\/Reports\.aspx/i.test(url) && !/ReferralsByStatus/i.test(url)) return true;
  return false;
}

function pageKind(url = "") {
  if (/\/ReferralsByStatus_[^/]*\.aspx/i.test(url) || /\/ReferralsByStatus[^/]*\.aspx/i.test(url)) return "setup";
  if (looksLikeViewerUrl(url)) return "viewer";
  if (looksLikeLoginUrl(url)) return "login";
  return "portal";
}

function downloadLooksLikeReport(item = {}) {
  const url = item.url || "";
  const filename = item.filename || "";
  const mime = item.mime || "";
  const meta = `${filename} ${mime} ${url}`;
  if (/\.(css|js|png|jpe?g|gif|svg|ico|woff2?|map)(?:\b|$)/i.test(filename)) return false;
  if (/^image\/|^text\/css|^application\/javascript|^font\//i.test(mime)) return false;
  const fromPortal = isHhaUrl(url) || isHhaUrl(item.referrer || "");
  const looksLikeFile = /\.(xlsx|xls|zip|csv)(?:\b|$)|spreadsheetml|ms-excel|openxmlformats|EXCELOPENXML|Format=Excel|application\/zip|application\/octet-stream|application\/x-zip|ReportViewer|Reserved\.ReportViewer|\.axd/i.test(meta);
  if (looksLikeFile && (fromPortal || /ReportViewer|hhaexchange/i.test(url))) return true;
  // Excel from this viewer often starts with an empty name and a generic mime.
  // While an export is in flight, take the portal download instead of ignoring it.
  if (activeRun && (activeRun.exportClickedAt || activeRun.exportDispatchedAt) && fromPortal) {
    if (/text\/html/i.test(mime) && !/\.(xlsx|xls|zip|csv)(?:\b|$)/i.test(filename)) return false;
    return true;
  }
  return false;
}

function extensionFromDownload(item = {}) {
  const name = item.filename || "";
  const mime = item.mime || "";
  const meta = `${name} ${mime} ${item.url || ""}`;
  if (/\.xlsx$/i.test(name) || /spreadsheetml|openxmlformats|EXCELOPENXML/i.test(meta)) return "xlsx";
  if (/\.xls$/i.test(name) || /application\/vnd\.ms-excel/i.test(mime)) return "xls";
  if (/\.csv$/i.test(name) || /text\/csv/i.test(mime)) return "csv";
  if (/\.pdf$/i.test(name)) return "pdf";
  // A real zip archive must stay a zip. Only an Open XML stream is renamed to xlsx.
  if (/\.zip$/i.test(name) || /application\/zip|x-zip/i.test(mime)) {
    if (/spreadsheetml|openxmlformats|EXCELOPENXML|Format=Excel/i.test(meta)) return "xlsx";
    return "zip";
  }
  return "xlsx";
}

function sameLocalDay(ts, date = new Date()) {
  if (!ts) return false;
  const d = new Date(ts);
  return d.getFullYear() === date.getFullYear() && d.getMonth() === date.getMonth() && d.getDate() === date.getDate();
}

function formatClock(hour, minute) {
  const h = ((hour + 11) % 12) + 1;
  const suffix = hour >= 12 ? "PM" : "AM";
  return `${h}:${pad(minute)} ${suffix}`;
}

function weekdayName(date) {
  return ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"][date.getDay()];
}

function nextWeekdayFire(hour, minute, weekdaysOnly = true, from = new Date()) {
  const next = new Date(from.getTime());
  next.setSeconds(0, 0);
  next.setHours(hour, minute, 0, 0);
  if (next.getTime() <= from.getTime() + 15000) {
    next.setDate(next.getDate() + 1);
  }
  if (weekdaysOnly) {
    while (next.getDay() === 0 || next.getDay() === 6) {
      next.setDate(next.getDate() + 1);
    }
  }
  return next;
}

async function getSettings() {
  const stored = await chrome.storage.local.get(SETTINGS_KEY);
  return { ...DEFAULT_SETTINGS, ...(stored[SETTINGS_KEY] || {}) };
}

async function saveSettings(partial) {
  const current = await getSettings();
  const next = { ...current };
  for (const key of ["scheduleEnabled", "notifyOnComplete"]) {
    if (key in partial) next[key] = Boolean(partial[key]);
  }
  for (const [key, max] of [["hour", 23], ["minute", 59]]) {
    if (key in partial) {
      const value = Number(partial[key]);
      if (!Number.isInteger(value) || value < 0 || value > max) throw new Error(`Invalid ${key}.`);
      next[key] = value;
    }
  }
  if ("downloadFolder" in partial) next.downloadFolder = validateFolder(partial.downloadFolder);
  next.weekdaysOnly = true;
  await chrome.storage.local.set({ [SETTINGS_KEY]: next });
  await scheduleNextAlarm();
  return next;
}

function validateFolder(value) {
  const folder = String(value || "").trim().replace(/\\/g, "/");
  if (folder.length > 160 || /[<>:"|?*\x00-\x1f]/.test(folder) || folder.startsWith("/") ||
      (folder && folder.split("/").some(part => !part || part === "." || part === ".." || /[. ]$/.test(part) || /^(con|prn|aux|nul|com[1-9]|lpt[1-9])(?:\.|$)/i.test(part)))) {
    throw new Error("Use a folder inside Downloads, such as HHA Reports. Absolute paths and .. are not allowed.");
  }
  return folder;
}

async function saveRun() {
  if (activeRun) await chrome.storage.local.set({ [RUN_KEY]: activeRun });
  else await chrome.storage.local.remove(RUN_KEY);
}

async function setPendingRename(enabled) {
  if (enabled) {
    renameState = {
      enabled: true,
      startedAt: Date.now(),
      base: `Report of ${filenameDate(new Date(activeRun?.startedAt || Date.now()))}`,
      folder: validateFolder((await getSettings()).downloadFolder)
    };
    await chrome.storage.local.set({ [RENAME_KEY]: renameState });
  } else {
    renameState = { enabled: false, base: "", startedAt: 0 };
    await chrome.storage.local.remove(RENAME_KEY);
  }
}

async function pendingRename() {
  if (renameState?.enabled && Date.now() - renameState.startedAt <= 20 * 60 * 1000) {
    return renameState;
  }
  const stored = await chrome.storage.local.get(RENAME_KEY);
  const pending = stored[RENAME_KEY];
  if (!pending?.enabled) return null;
  if (Date.now() - pending.startedAt > 20 * 60 * 1000) {
    await setPendingRename(false);
    return null;
  }
  renameState = pending;
  return pending;
}

async function rememberPortal(url) {
  if (!isHhaUrl(url) || looksLikeLoginUrl(url)) return;
  try {
    const origin = new URL(url).origin + "/";
    await chrome.storage.local.set({ [PORTAL_KEY]: origin });
  } catch (_) {}
}

async function lastPortalUrl() {
  const stored = await chrome.storage.local.get(PORTAL_KEY);
  return stored[PORTAL_KEY] || DEFAULT_PORTAL;
}

async function log(message, level = "info") {
  if (!activeRun) return;
  activeRun.logs = activeRun.logs || [];
  activeRun.logs.push({ at: new Date().toISOString(), level, message });
  activeRun.logs = activeRun.logs.slice(-40);
  activeRun.statusMessage = message;
  await saveRun();
}

async function setBadge(text, color = "#2f4a3c") {
  try {
    await chrome.action.setBadgeText({ text: text || "" });
    if (text) await chrome.action.setBadgeBackgroundColor({ color });
  } catch (_) {}
}

async function notifyUser({ id, title, message, buttons }) {
  const opts = {
    type: "basic",
    iconUrl: "icons/icon128.png",
    title,
    message,
    priority: 2,
    requireInteraction: true,
    silent: false
  };
  if (buttons?.length) opts.buttons = buttons;
  try {
    await chrome.notifications.create(id || `hha-${Date.now()}`, opts);
  } catch (_) {
    try {
      delete opts.buttons;
      await chrome.notifications.create(id || `hha-${Date.now()}`, opts);
    } catch (__) {}
  }
}

async function finish(success, message) {
  if (!activeRun || finishingRun) return;
  finishingRun = true;
  const trackedIds = Array.from(activeRun.trackedTabIds || []);
  const savedAs = activeRun.savedAs;
  const runId = activeRun.id;
  stopHeartbeat();
  exportRetryCount = 0;
  try { await chrome.alarms.clear(WATCH_ALARM); } catch (_) {}
  if (downloadWatchdog) {
    clearTimeout(downloadWatchdog);
    downloadWatchdog = null;
  }
  const completed = {
    ...activeRun,
    success,
    status: success ? "complete" : "error",
    statusMessage: message,
    completedAt: Date.now()
  };
  await chrome.storage.local.set({ [LAST_KEY]: completed });
  const storedHistory = await chrome.storage.local.get(HISTORY_KEY);
  const history = storedHistory[HISTORY_KEY] || [];
  history.unshift({ id: completed.id, success, savedAs: completed.savedAs || "", downloadId: completed.downloadId,
    startedAt: completed.startedAt, completedAt: completed.completedAt, durationMs: completed.completedAt - completed.startedAt,
    trigger: completed.trigger, statusMessage: message });
  await chrome.storage.local.set({ [HISTORY_KEY]: history.slice(0, 12) });
  await broadcastRunFinished({
    runId,
    success,
    message,
    savedAs,
    tabIds: trackedIds
  });
  await setPendingRename(false);
  if (!success) {
    await setBadge("!", "#8b3a2d");
  } else {
    await setBadge("✓", "#2f4a3c");
  }
  activeRun = null;
  await saveRun();
  finishingRun = false;
  if (!success && message !== "Automation stopped by user.") {
    await notifyUser({ id: "hha-report-failed", title: "Report needs attention", message });
  }
}

async function broadcastRunFinished({ success, message, savedAs, runId, tabIds = [] }) {
  const payload = {
    type: "HHA_RUN_FINISHED",
    runId,
    success: Boolean(success),
    message: message || "",
    savedAs: savedAs || ""
  };
  const tabs = await chrome.tabs.query({ url: ["*://*.hhaexchange.com/*", "*://hhaexchange.com/*"] }).catch(() => []);
  const ids = new Set([
    ...tabIds.filter(Boolean),
    ...tabs.map((t) => t.id).filter(Boolean)
  ]);
  for (const id of ids) {
    try { await chrome.tabs.sendMessage(id, payload); } catch (_) {}
  }
}

function pageEvalMain(op, args) {
  const $find = window.$find;
  const pad = (n) => String(n).padStart(2, "0");

  function dateParts(d) {
    return {
      display: `${d.getMonth() + 1}/${d.getDate()}/${d.getFullYear()}`,
      padded: `${pad(d.getMonth() + 1)}/${pad(d.getDate())}/${d.getFullYear()}`,
      validationText: `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}-00-00-00`
    };
  }

  function applyClientState(el, d) {
    if (!el || el.type !== "hidden") return;
    const { display, validationText } = dateParts(d);
    try {
      const json = el.value ? JSON.parse(el.value) : {};
      json.validationText = validationText;
      json.valueAsString = validationText;
      json.lastSetTextBoxValue = display;
      el.value = JSON.stringify(json);
    } catch (_) {
      el.value = JSON.stringify({
        enabled: true,
        emptyMessage: "",
        validationText,
        valueAsString: validationText,
        lastSetTextBoxValue: display
      });
    }
  }

  function applyWidget(widget, d) {
    if (!widget) return false;
    const { display } = dateParts(d);
    try {
      if (widget.set_selectedDate) widget.set_selectedDate(d);
      const di = widget.get_dateInput && widget.get_dateInput();
      if (di) {
        if (di.set_selectedDate) di.set_selectedDate(d);
        if (di.set_value) di.set_value(display);
        if (di.set_text) di.set_text(display);
      }
      return true;
    } catch (_) {
      return false;
    }
  }

  function setInputDate(input, d) {
    if (!input) return { ok: false };
    const { display } = dateParts(d);
    let widgetOk = false;
    const picker = input.closest && input.closest(".RadPicker, .RadDatePicker, [class*='RadPicker']");
    if ($find) {
      widgetOk = applyWidget($find(input.id), d) || widgetOk;
      if (picker && picker.id) widgetOk = applyWidget($find(picker.id), d) || widgetOk;
    }
    const scope = picker || input.parentElement || document;
    const hiddens = scope.querySelectorAll
      ? scope.querySelectorAll("input[type='hidden']")
      : [];
    for (let i = 0; i < hiddens.length; i += 1) {
      const hid = hiddens[i];
      if (/ClientState|dateInput|Date/i.test(hid.id || hid.name || "")) applyClientState(hid, d);
    }
    try {
      const proto = window.HTMLInputElement && window.HTMLInputElement.prototype;
      const nativeSet = proto && Object.getOwnPropertyDescriptor(proto, "value") && Object.getOwnPropertyDescriptor(proto, "value").set;
      if (nativeSet) nativeSet.call(input, display);
      else input.value = display;
    } catch (_) {
      input.value = display;
    }
    try { input.dispatchEvent(new Event("input", { bubbles: true })); } catch (_) {}
    try { input.dispatchEvent(new Event("change", { bubbles: true })); } catch (_) {}
    return { ok: true, widgetOk, value: input.value };
  }

  function labelText(el) {
    return String(el.innerText || el.textContent || "")
      .replace(/\s+/g, " ")
      .trim()
      .replace(/:\s*$/, "")
      .toLowerCase();
  }

  function findLabeledDateInput(wanted) {
    const nodes = Array.from(document.querySelectorAll("label, td, th, span, div"));
    for (let i = 0; i < nodes.length; i += 1) {
      const n = nodes[i];
      if (labelText(n) !== wanted) continue;
      const row = n.closest("tr") || n.parentElement;
      if (!row) continue;
      const inputs = Array.from(row.querySelectorAll("input.riTextBox, input[type='text'], input:not([type])"))
        .filter((el) => el.type !== "hidden" && el.type !== "checkbox" && el.type !== "button" && el.type !== "submit");
      if (!inputs.length) continue;
      const nRect = n.getBoundingClientRect ? n.getBoundingClientRect() : { left: 0 };
      inputs.sort((a, b) => {
        const ar = a.getBoundingClientRect ? a.getBoundingClientRect().left : 0;
        const br = b.getBoundingClientRect ? b.getBoundingClientRect().left : 0;
        return Math.abs(ar - nRect.left) - Math.abs(br - nRect.left);
      });
      return inputs[0];
    }
    return null;
  }

  if (op === "telerikSetDate") {
    const id = args && args.id;
    const d = new Date(args && args.timestamp);
    const input = (id && document.getElementById(id)) || null;
    if (!input) return { ok: false, error: "no input" };
    return setInputDate(input, d);
  }

  if (op === "setReceivedDatesToday") {
    const d = new Date(args && args.timestamp);
    const fromInput =
      findLabeledDateInput("received from date") ||
      findLabeledDateInput("received from");
    const toInput =
      findLabeledDateInput("received to date") ||
      findLabeledDateInput("received to");
    const from = setInputDate(fromInput, d);
    const to = setInputDate(toInput, d);
    return {
      ok: Boolean(from.ok && to.ok),
      from: from.value || (fromInput && fromInput.value) || "",
      to: to.value || (toInput && toInput.value) || "",
      fromFound: Boolean(fromInput),
      toFound: Boolean(toInput)
    };
  }

  if (op === "exportExcel") {
    const formats = ["EXCELOPENXML", "ExcelOpenXml"];
    const fallback = ["Excel", "EXCEL"];
    function isLoadingViewer(c) {
      try { if (typeof c.get_isLoading === "function" && c.get_isLoading()) return true; } catch (_) {}
      try { if (typeof c.get_isLoadingClient === "function" && c.get_isLoadingClient()) return true; } catch (_) {}
      try { if (c.isLoading === true) return true; } catch (_) {}
      return false;
    }
    const tryExport = (c) => {
      if (!c || typeof c.exportReport !== "function") return null;
      if (isLoadingViewer(c)) return { blocked: "loading" };
      try {
        if (typeof c.get_reportAreaContentType === "function") {
          const ct = c.get_reportAreaContentType();
          if (ct === 0 || ct === "None") return { blocked: "no-report" };
        }
      } catch (_) {}
      const all = formats.concat(fallback);
      for (let i = 0; i < all.length; i += 1) {
        try {
          c.exportReport(all[i]);
          return { format: all[i] };
        } catch (e) {
          const msg = String((e && e.message) || e);
          if (/being updated|no report loaded/i.test(msg)) return { blocked: msg };
        }
      }
      return null;
    };
    try {
      const getComponents = window.Sys && window.Sys.Application && window.Sys.Application.get_components;
      const list = getComponents ? window.Sys.Application.get_components() : [];
      let blocked = null;
      for (let i = 0; i < list.length; i += 1) {
        const result = tryExport(list[i]);
        if (result && result.format) return { ok: true, format: result.format };
        if (result && result.blocked) blocked = result.blocked;
      }
      const dict = window.Sys && window.Sys.Application && window.Sys.Application._components;
      if (dict && $find) {
        const ids = Object.keys(dict);
        for (let i = 0; i < ids.length; i += 1) {
          const result = tryExport($find(ids[i]));
          if (result && result.format) return { ok: true, format: result.format, id: ids[i] };
          if (result && result.blocked) blocked = result.blocked;
        }
      }
      if (blocked) return { ok: false, error: blocked };
    } catch (e) {
      return { ok: false, error: String(e) };
    }
    return { ok: false };
  }

  if (op === "reportViewerState") {
    function vis(el) {
      if (!el) return false;
      try {
        const s = window.getComputedStyle(el);
        if (s.display === "none" || s.visibility === "hidden" || Number(s.opacity) === 0) return false;
        const r = el.getBoundingClientRect();
        return r.width > 0 && r.height > 0;
      } catch (_) {
        return false;
      }
    }
    try {
      let hasViewer = false;
      let totalPages = 0;
      let rendered = false;
      let hasExport = false;
      let exportEnabled = false;
      let contentType = null;

      const waitNodes = Array.from(document.querySelectorAll("[id$='AsyncWait_Wait'], [id$='AsyncWait'], [id*='AsyncWait'], .WaitControl"));
      let overlayLoading = false;
      for (let w = 0; w < waitNodes.length; w += 1) {
        const wait = waitNodes[w];
        if (!vis(wait)) continue;
        const box = wait.getBoundingClientRect();
        if (box.width >= 24 && box.height >= 24) overlayLoading = true;
      }

      const reportSurface = document.querySelector("[id*='VisibleReportContent'], [id$='ReportArea']");
      if (reportSurface) {
        const surfaceText = String(reportSurface.innerText || reportSurface.textContent || "");
        const box = reportSurface.getBoundingClientRect();
        if (box.height > 70 && /Page\s+\d+\s+of\s+\d+/i.test(surfaceText)) rendered = true;
      }

      const bodyText = String((document.body && (document.body.innerText || document.body.textContent)) || "");
      const pageMatch = bodyText.match(/Page\s+(\d+)\s+of\s+(\d+)/i);
      if (pageMatch && Number(pageMatch[2]) > 0) {
        rendered = true;
        totalPages = Number(pageMatch[2]);
      }

      const exportSel = [
        '[title*="Export" i]',
        '[aria-label*="Export" i]',
        'img[alt*="Export" i]',
        'img[src*="Save.gif" i]',
        'img[src*="Icons.Save" i]',
        'input[type="image"][title*="Export" i]',
        'a[id*="Export" i]',
        'button[id*="Export" i]'
      ];
      for (let i = 0; i < exportSel.length; i += 1) {
        const nodes = Array.from(document.querySelectorAll(exportSel[i]));
        const hit = nodes.find(vis);
        if (hit) {
          hasExport = true;
          const clickable = hit.closest("a,button,input") || hit;
          exportEnabled = !clickable.disabled && String(clickable.getAttribute && clickable.getAttribute("aria-disabled") || "").toLowerCase() !== "true";
          break;
        }
      }

      let apiLoading = false;
      const getComponents = window.Sys && window.Sys.Application && window.Sys.Application.get_components;
      const list = getComponents ? window.Sys.Application.get_components() : [];
      for (let i = 0; i < list.length; i += 1) {
        const c = list[i];
        if (!c) continue;
        if (typeof c.exportReport === "function" || typeof c.get_isLoading === "function") {
          hasViewer = true;
          try { if (typeof c.get_isLoading === "function" && c.get_isLoading()) apiLoading = true; } catch (_) {}
          try { if (typeof c.get_isLoadingClient === "function" && c.get_isLoadingClient()) apiLoading = true; } catch (_) {}
          try { if (c.isLoading === true) apiLoading = true; } catch (_) {}
          try {
            if (typeof c.get_totalPages === "function") {
              const n = Number(c.get_totalPages());
              if (n > totalPages) totalPages = n;
              if (n > 0) rendered = true;
            }
          } catch (_) {}
          try {
            if (typeof c.get_reportAreaContentType === "function") {
              contentType = c.get_reportAreaContentType();
              if (contentType === 1 || contentType === 2 || contentType === "ReportPage") rendered = true;
            }
          } catch (_) {}
        }
      }
      return {
        ok: true,
        loading: overlayLoading,
        overlayLoading,
        apiLoading,
        hasViewer,
        totalPages,
        rendered,
        hasExport,
        exportEnabled,
        contentType,
        frame: window !== window.top
      };
    } catch (e) {
      return { ok: false, error: String(e) };
    }
  }

  function clickViewButton() {
    function vis(el) {
      if (!el) return false;
      const s = window.getComputedStyle(el);
      if (s.display === "none" || s.visibility === "hidden" || Number(s.opacity) === 0) return false;
      const r = el.getBoundingClientRect();
      return r.width > 0 && r.height > 0;
    }
    const nodes = Array.from(document.querySelectorAll("input, button, a"));
    const btn = nodes.find((el) => {
      const t = String(el.value || el.innerText || el.textContent || el.title || "")
        .replace(/\s+/g, " ")
        .trim()
        .toLowerCase();
      return t === "view report" && vis(el);
    });
    if (!btn) return { ok: false, error: "no View Report button" };
    try {
      const oc = String((btn.getAttribute && btn.getAttribute("onclick")) || "");
      const postback = oc.match(/__doPostBack\(\s*'([^']+)'\s*,\s*'([^']*)'\s*\)/);
      if (postback && typeof window.__doPostBack === "function") window.__doPostBack(postback[1], postback[2]);
      else btn.click();
    } catch (e) {
      return { ok: false, error: String(e) };
    }
    const form = btn.form || (btn.closest && btn.closest("form")) || document.forms[0];
    return { ok: true, tag: btn.tagName, name: btn.name || "", target: (form && form.target) || "" };
  }

  if (op === "commitDatesAndView") {
    const d = new Date(args && args.timestamp);
    const fromInput =
      (args && args.fromId && document.getElementById(args.fromId)) ||
      findLabeledDateInput("received from date") ||
      findLabeledDateInput("received from");
    const toInput =
      (args && args.toId && document.getElementById(args.toId)) ||
      findLabeledDateInput("received to date") ||
      findLabeledDateInput("received to");
    const from = setInputDate(fromInput, d);
    const to = setInputDate(toInput, d);
    if ($find && args) {
      if (args.pickerFromId) applyWidget($find(args.pickerFromId), d);
      if (args.pickerToId) applyWidget($find(args.pickerToId), d);
    }
    const view = clickViewButton();
    return {
      ok: Boolean(view.ok),
      viewOk: Boolean(view.ok),
      datesOk: Boolean(from.ok && to.ok),
      from: from.value || "",
      to: to.value || "",
      error: view.error || ""
    };
  }

  if (op === "clickViewReport") return clickViewButton();

  if (op === "clickExportExcel") {
    function vis(el) {
      if (!el) return false;
      const s = window.getComputedStyle(el);
      if (s.display === "none" || s.visibility === "hidden" || Number(s.opacity) === 0) return false;
      const r = el.getBoundingClientRect();
      return r.width > 0 && r.height > 0;
    }
    function txt(el) {
      return String(el.value || el.innerText || el.textContent || el.title || el.alt || "")
        .replace(/\s+/g, " ")
        .trim()
        .toLowerCase();
    }
    const step = (args && args.step) || "excel";
    if (step === "export" || step === "both") {
      const exportSel = [
        '[title*="Export" i]',
        '[aria-label*="Export" i]',
        'img[alt*="Export" i]',
        'img[src*="Save.gif" i]',
        'img[src*="Icons.Save" i]',
        'input[type="image"][title*="Export" i]',
        'a[id*="Export" i]',
        'button[id*="Export" i]'
      ];
      let exportBtn = null;
      for (let i = 0; i < exportSel.length; i += 1) {
        const nodes = Array.from(document.querySelectorAll(exportSel[i]));
        exportBtn = nodes.find(vis) || exportBtn;
        if (exportBtn) break;
      }
      if (!exportBtn) {
        const imgs = Array.from(document.querySelectorAll("img")).filter(vis);
        for (let i = 0; i < imgs.length; i += 1) {
          const meta = txt(imgs[i]) + " " + String(imgs[i].src || "").toLowerCase();
          if (meta.indexOf("export") !== -1 || meta.indexOf("save.gif") !== -1) {
            exportBtn = imgs[i].closest("a,button,td") || imgs[i];
            break;
          }
        }
      }
      if (exportBtn) {
        try { (exportBtn.closest("a,button") || exportBtn).click(); } catch (_) {}
        if (step === "export") return { ok: true, via: "export-icon" };
      } else if (step === "export") {
        return { ok: false, error: "no export icon" };
      }
    }
    const candidates = Array.from(document.querySelectorAll("a, button, td, li, [role='menuitem']")).filter(vis);
    let excel = null;
    let score = 0;
    for (let i = 0; i < candidates.length; i += 1) {
      const t = txt(candidates[i]);
      if (!t || t.length > 48) continue;
      if (/\b(pdf|word|csv|tiff|mhtml|xml file|web archive)\b/.test(t) && t.indexOf("excel") === -1) continue;
      if (t === "xml" || t === "zip") continue;
      let s = 0;
      if (t === "excel open xml" || t === "excel (open xml)" || t === "excelopenxml") s = 110;
      else if (t === "excel" || t === "excel worksheet") s = 100;
      else if (t.indexOf("xlsx") !== -1) s = 95;
      else if (t.indexOf("excel") === 0) s = 70;
      if (s > score) {
        score = s;
        excel = candidates[i];
      }
    }
    if (!excel) return { ok: false, error: "no Excel option" };
    try { excel.click(); } catch (e) { return { ok: false, error: String(e) }; }
    return { ok: true, via: "menu", format: txt(excel) };
  }

  return { ok: false, error: "unknown op" };
}

function scoreViewerState(r) {
  if (!r || r.ok === false) return -1;
  let s = 0;
  if (r.hasViewer) s += 50;
  if (r.rendered) s += 40;
  if (r.hasExport) s += 20;
  if (r.exportEnabled) s += 15;
  if ((r.totalPages || 0) > 0) s += 15;
  if (r.frame) s += 8;
  if (r.overlayLoading) s -= 25;
  else if (r.loading) s -= 20;
  if (r.apiLoading) s -= 2;
  return s;
}

function pickPageEvalResult(op, injections) {
  const results = (injections || []).map((i) => i?.result).filter(Boolean);
  if (!results.length) return { ok: false };

  if (op === "reportViewerState") {
    const best = [...(injections || [])].filter(row => row.result && row.result.ok !== false)
      .sort((a, b) => scoreViewerState(b.result) - scoreViewerState(a.result))[0];
    return best ? { ...best.result, frameId: best.frameId, frames: results.length } : { ok: false };
  }

  const success = results.find((r) => r.ok);
  if (success) return success;
  const withViewer = results.find((r) => r.hasViewer);
  if (withViewer) return withViewer;
  const blocked = results.find((r) => r.error);
  if (blocked) return blocked;
  return results[results.length - 1] || { ok: false };
}

async function executeIn(tabId, mode, operation, operationArgs) {
  const target = mode === "all"
    ? { tabId, allFrames: true }
    : mode === "top"
      ? { tabId }
      : { tabId, frameIds: [mode] };
  return chrome.scripting.executeScript({
    target,
    world: "MAIN",
    func: pageEvalMain,
    args: [operation, operationArgs || {}]
  });
}

async function pageEval(tabId, op, args, preferredFrameId) {
  const targeted = op === "exportExcel" || op === "reportViewerState" || op === "clickExportExcel";
  try {
    if (targeted && preferredFrameId != null) {
      try {
        const direct = await executeIn(tabId, preferredFrameId, op, args);
        const result = direct?.[0]?.result;
        const strong = op === "reportViewerState"
          ? scoreViewerState(result) >= 55
          : Boolean(result && (result.ok || result.error || result.blocked));
        if (strong) return { ...result, frameId: preferredFrameId };
      } catch (_) {}
    }

    if (op === "exportExcel" || op === "clickExportExcel") {
      const states = await executeIn(tabId, "all", "reportViewerState", {});
      const ranked = (states || [])
        .map((row) => ({
          frameId: row.frameId,
          score: scoreViewerState(row.result),
          result: row.result
        }))
        .sort((a, b) => b.score - a.score);
      const best = ranked.find((row) => row.score > 0) || ranked[0];
      if (!best || best.frameId == null) return { ok: false, error: "no viewer frame" };
      const injections = await executeIn(tabId, best.frameId, op, args);
      return { ...(injections?.[0]?.result || { ok: false }), frameId: best.frameId };
    }

    const injections = await executeIn(tabId, targeted ? "all" : "top", op, args);
    if (targeted) return pickPageEvalResult(op, injections);
    return injections?.[0]?.result || { ok: false };
  } catch (error) {
    return { ok: false, error: error.message };
  }
}

async function ensureContentScript(tabId) {
  try {
    await chrome.tabs.sendMessage(tabId, { type: "HHA_PING" });
    return true;
  } catch (_) {}
  try {
    await chrome.scripting.executeScript({
      target: { tabId },
      files: ["config.js", "automation.js"]
    });
    await chrome.tabs.sendMessage(tabId, { type: "HHA_PING" });
    return true;
  } catch (_) {
    return false;
  }
}

async function send(tabId, message) {
  const ready = await ensureContentScript(tabId);
  if (!ready) throw new Error("HHAeXchange tab is not ready yet. Stay logged in and try again.");
  return chrome.tabs.sendMessage(tabId, { ...message, runId: activeRun?.id });
}

async function findHhaTab() {
  const tabs = await chrome.tabs.query({ url: ["*://*.hhaexchange.com/*", "*://hhaexchange.com/*"] });
  if (!tabs.length) return null;
  const scored = tabs.filter(tab => pageKind(tab.url || "") !== "viewer").map((tab) => {
    const url = tab.url || "";
    let s = 0;
    if (/ReferralsByStatus/i.test(url)) s += 50;
    if (/Reports\.aspx/i.test(url)) s += 30;
    if (pageKind(url) === "portal") s += 20;
    if (looksLikeLoginUrl(url)) s -= 80;
    if (tab.active) s += 4;
    if (tab.status === "complete") s += 2;
    return { tab, s };
  });
  scored.sort((a, b) => b.s - a.s);
  return scored[0]?.tab || null;
}

function waitTabComplete(tabId, timeoutMs = 45000) {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => {
      chrome.tabs.onUpdated.removeListener(onUpdated);
      reject(new Error("HHAeXchange tab took too long to load."));
    }, timeoutMs);

    function onUpdated(id, info, tab) {
      if (id !== tabId) return;
      if (info.status === "complete") {
        clearTimeout(timer);
        chrome.tabs.onUpdated.removeListener(onUpdated);
        resolve(tab);
      }
    }

    chrome.tabs.onUpdated.addListener(onUpdated);
    chrome.tabs.get(tabId).then((tab) => {
      if (tab.status === "complete") {
        clearTimeout(timer);
        chrome.tabs.onUpdated.removeListener(onUpdated);
        resolve(tab);
      }
    }).catch(() => {});
  });
}

async function findOrOpenHhaTab() {
  const existing = await findHhaTab();
  if (existing?.id) {
    try {
      await chrome.tabs.update(existing.id, { autoDiscardable: false });
    } catch (_) {}
    return existing;
  }

  const url = await lastPortalUrl();
  const tab = await chrome.tabs.create({ url, active: false });
  try {
    await chrome.tabs.update(tab.id, { autoDiscardable: false });
  } catch (_) {}
  const loaded = await waitTabComplete(tab.id);
  return loaded || tab;
}

async function keepWindowInBackground(win) {
  if (!activeRun?.keepInBackground || !win?.id) return;
  if (activeRun.stage === "waitingViewer" || activeRun.stage === "exporting") return;
  try {
    const tabs = await chrome.tabs.query({ windowId: win.id });
    const isHha = tabs.some((t) => isHhaUrl(t.url || t.pendingUrl || ""));
    if (isHha) await chrome.windows.update(win.id, { focused: false });
  } catch (_) {}
}

async function startDownloadWatchdog() {
  if (!activeRun) return;
  if (downloadWatchdog) clearTimeout(downloadWatchdog);
  const delay = activeRun.stage === "waitingDownload"
    ? 180000
    : (activeRun.exportClickedAt ? 50000 : 20000);
  downloadWatchdog = setTimeout(async () => {
    if (!activeRun) return;
    if (activeRun.stage === "waitingDownload") {
      await finish(
        false,
        "The Excel file started downloading but did not finish. Check Chrome’s download shelf and retry."
      );
      return;
    }
    if (activeRun.exportClickedAt && !acceptedDownloadId) {
      if (exportRetryCount < 1) {
        exportRetryCount += 1;
        activeRun.exportRetryCount = exportRetryCount;
        await log("Excel file did not start. Trying export one more time…");
        await kickExcelOnViewerTabs({ force: true });
        await startDownloadWatchdog();
        return;
      }
      await finish(
        false,
        "Excel export was clicked, but Chrome never reported a finished download. Check your Downloads folder or retry."
      );
    }
  }, delay);
}

function shouldIgnoreExistingTab(tabId) {
  if (!activeRun?.existingTabIds?.includes(tabId)) return false;
  if (tabId === activeRun.rootTabId) return false;
  if (activeRun.adoptedTabIds?.includes(tabId)) return false;
  return true;
}

async function adoptViewerTab(tabId) {
  if (!activeRun || !tabId) return;
  activeRun.adoptedTabIds = Array.from(new Set([...(activeRun.adoptedTabIds || []), tabId]));
  activeRun.trackedTabIds = Array.from(new Set([...(activeRun.trackedTabIds || []), tabId]));
  exportSentTabs.delete(tabId);
  await saveRun();
}

async function kickExcelOnViewerTabs({ force = false } = {}) {
  if (!activeRun || activeRun.stage === "waitingDownload") return;
  if (!force && activeRun.exportClickedAt) return;
  const tabs = await chrome.tabs.query({ url: ["*://*.hhaexchange.com/*", "*://hhaexchange.com/*"] });
  for (const tab of tabs) {
    const url = tab.url || "";
    const kind = pageKind(url);
    const tracked = activeRun.trackedTabIds?.includes(tab.id);
    if (!tracked || shouldIgnoreExistingTab(tab.id)) continue;
    if (force && activeRun.exportOwnerTabId != null && tab.id !== activeRun.exportOwnerTabId) continue;
    const isViewer = kind === "viewer" || (tracked && tab.id !== activeRun.rootTabId && kind !== "setup" && kind !== "login");
    if (!isViewer && !(tracked && kind === "setup")) continue;
    try {
      if (kind === "setup") {
        if (activeRun.stage === "configuring") continue;
        if (activeRun.exportClickedAt && !force) continue;
        await send(tab.id, force ? { type: "HHA_EXPORT_EXCEL", force: true } : { type: "HHA_AFTER_VIEW" });
      } else {
        const sentAt = activeRun.exportSentAt?.[tab.id] || 0;
        if (!force && exportSentTabs.has(tab.id) && (activeRun.exportClickedAt || Date.now() - sentAt < 12000)) continue;
        exportSentTabs.add(tab.id);
        activeRun.exportSentAt = { ...(activeRun.exportSentAt || {}), [tab.id]: Date.now() };
        await send(tab.id, { type: "HHA_EXPORT_EXCEL", force: Boolean(force) });
      }
    } catch (_) {}
  }
}

async function onReportDownloaded(item = {}) {
  if (!activeRun || finishingRun) return;
  if (activeRun.downloadId != null && item.id != null && item.id !== activeRun.downloadId) return;
  if (runSucceeded) return;
  if (acceptedDownloadId && item.id && item.id !== acceptedDownloadId) return;
  runSucceeded = true;
  const ext = extensionFromDownload(item);
  const pending = await pendingRename();
  const name = (item.filename || "").split(/[/\\]/).pop() || (pending?.base ? `${pending.base}.${ext}` : reportFilename(ext));
  if (activeRun) {
    activeRun.savedAs = name;
    await log(`Download finished: ${name}`);
    await finish(true, `${activeRun.stateLabel} report saved as ${name}.`);
  } else {
    await chrome.storage.local.set({
      [LAST_KEY]: {
        success: true,
        status: "complete",
        statusMessage: `Report saved as ${name}.`,
        completedAt: Date.now(),
        savedAs: name,
        stateLabel: "Maryland"
      }
    });
    await setBadge("✓", "#2f4a3c");
    await broadcastRunFinished({
      success: true,
      message: `Report saved as ${name}.`,
      savedAs: name
    });
  }
  if ((await getSettings()).notifyOnComplete) await notifyUser({
    id: "hha-report-ready",
    title: "Maryland daily report is ready",
    message: `${name} is saved. Select Show file to find it.`,
    buttons: [{ title: "Show file" }]
  });
}

async function startRun({ trigger = "manual", state = "maryland" } = {}) {
  if (startingRun || finishingRun) return { ok: false, error: "A report pull is starting or finishing. Please try again in a moment." };
  startingRun = true;
  const generation = ++startupGeneration;
  try { return await beginRun({ trigger, state, generation }); } finally { startingRun = false; }
}

async function beginRun({ trigger, state, generation }) {
  const cfg = globalThis.HHA_REPORT_CONFIG?.[state];
  if (!cfg) return { ok: false, error: "Unknown state." };
  if (activeRun) return { ok: false, error: "A report pull is already running." };

  acceptedDownloadId = null;
  exportSentTabs.clear();
  exportRetryCount = 0;
  runSucceeded = false;

  await setBadge("…", "#6e6b62");
  const tab = await findOrOpenHhaTab();
  if (generation !== startupGeneration) return { ok: false, error: "Automation stopped by user." };
  if (!tab?.id) {
    await setBadge("", "#2f4a3c");
    return { ok: false, error: "Could not open an HHAeXchange tab." };
  }

  const url = tab.url || "";
  if (looksLikeLoginUrl(url) || pageKind(url) === "login") {
    await setBadge("!", "#8b3a2d");
    await notifyUser({
      id: "hha-need-login",
      title: "Log in to pull today’s report",
      message: "Sign in to Maryland HHAeXchange, then click Pull today’s report.",
      buttons: [{ title: "Show portal tab" }]
    });
    try { await chrome.tabs.update(tab.id, { active: true }); } catch (_) {}
    return { ok: false, error: "Open the logged-in Maryland HHAeXchange portal, then try again." };
  }

  if (!isHhaUrl(url) && trigger === "manual") {
    await setBadge("", "#2f4a3c");
    return { ok: false, error: "Open the logged-in Maryland HHAeXchange portal first. You can stay on another tab after that — the pull runs in the background." };
  }

  const existingTabs = await chrome.tabs.query({ url: ["*://*.hhaexchange.com/*", "*://hhaexchange.com/*"] });
  if (generation !== startupGeneration) return { ok: false, error: "Automation stopped by user." };
  activeRun = {
    id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
    state,
    stateLabel: cfg.label,
    startedAt: Date.now(),
    rootTabId: tab.id,
    trackedTabIds: [tab.id],
    existingTabIds: existingTabs.map(item => item.id),
    stage: "navigating",
    status: "running",
    statusMessage: `Starting ${cfg.label} daily report…`,
    logs: [],
    targetFilename: reportFilename("xlsx"),
    trigger,
    keepInBackground: false,
    exportClickedAt: 0
  };
  await saveRun();
  await setPendingRename(true);
  exportRetryCount = 0;
  await rememberPortal(url);
  try {
    const tabs = await chrome.tabs.query({ url: ["*://*.hhaexchange.com/*", "*://hhaexchange.com/*"] });
    for (const t of tabs) {
      try { await chrome.tabs.sendMessage(t.id, { type: "HHA_RUN_START", runId: activeRun.id }); } catch (_) {}
    }
  } catch (_) {}
  await log(
    trigger === "schedule"
      ? `Scheduled pull — ${cfg.label} Referral Patients By Status.`
      : `Starting ${cfg.label} Referral Patients By Status. The portal tab comes forward so the report can finish rendering.`
  );
  await armRunWatch();
  try { await focusTab(tab); } catch (_) {}

  try {
    const kind = pageKind(url);
    if (kind === "setup") {
      activeRun.stage = "configuring";
      await saveRun();
      await send(tab.id, { type: "HHA_CONFIGURE_REPORT", state });
    } else if (kind === "viewer") {
      activeRun.stage = "exporting";
      await saveRun();
      await send(tab.id, { type: "HHA_EXPORT_EXCEL" });
    } else {
      await send(tab.id, { type: "HHA_NAVIGATE" });
    }
    return { ok: true };
  } catch (error) {
    await finish(false, `Could not start automation on the HHAeXchange tab: ${error.message}`);
    return { ok: false, error: error.message };
  }
}

async function routeTab(tabId, url) {
  if (!activeRun || !isHhaUrl(url)) return;

  const kind = pageKind(url);
  if (kind === "login") {
    await finish(false, "HHAeXchange asked you to sign in. Log in, then pull the report again.");
    await notifyUser({
      id: "hha-need-login",
      title: "HHAeXchange session expired",
      message: "Log in and I’ll pull the Maryland daily report.",
      buttons: [{ title: "Show portal tab" }]
    });
    return;
  }

  if (kind === "setup" && (activeRun.stage === "waitingGenerate" || activeRun.stage === "waitingViewer")) {
    activeRun.trackedTabIds = Array.from(new Set([...(activeRun.trackedTabIds || []), tabId]));
    await log("Filter page reloaded after View Report. Checking for the report view, then Excel…");
    try {
      await send(tabId, { type: "HHA_AFTER_VIEW" });
    } catch (error) {
      await finish(false, `Could not finish after View Report: ${error.message}`);
    }
    return;
  }

  if (kind === "setup" && activeRun.stage !== "configuring" && activeRun.stage !== "exporting" && activeRun.stage !== "waitingDownload") {
    activeRun.stage = "configuring";
    activeRun.trackedTabIds = Array.from(new Set([...(activeRun.trackedTabIds || []), tabId]));
    await log("Report setup opened. Setting Received dates to today…");
    try {
      await send(tabId, { type: "HHA_CONFIGURE_REPORT", state: activeRun.state });
    } catch (error) {
      await finish(false, `Could not automate the report setup page: ${error.message}`);
    }
    return;
  }

  if (kind === "viewer" && activeRun.stage !== "waitingDownload") {
    if (activeRun.exportClickedAt) return;
    activeRun.stage = "exporting";
    activeRun.trackedTabIds = Array.from(new Set([...(activeRun.trackedTabIds || []), tabId]));
    await log("View window opened. Waiting for the report to finish drawing, then Excel…");
    startHeartbeat();
    try {
      if (!exportSentTabs.has(tabId) && !activeRun.exportClickedAt) {
        exportSentTabs.add(tabId);
        await send(tabId, { type: "HHA_EXPORT_EXCEL" });
      }
    } catch (error) {
      exportSentTabs.delete(tabId);
      await log(`Viewer tab not ready yet (${error.message}). Will retry.`);
    }
  }
}

async function focusTab(tab) {
  if (!tab?.id) return;
  try { await chrome.tabs.update(tab.id, { active: true, autoDiscardable: false }); } catch (_) {}
  if (tab.windowId) {
    try { await chrome.windows.update(tab.windowId, { focused: true }); } catch (_) {}
  }
}

async function watchForViewerTab(timeoutMs = 180000) {
  const started = Date.now();
  const known = new Set(activeRun?.trackedTabIds || []);
  while (
    activeRun &&
    (activeRun.stage === "waitingViewer" || activeRun.stage === "configuring" || activeRun.stage === "exporting") &&
    Date.now() - started < timeoutMs
  ) {
    if (activeRun.stage === "waitingDownload") return null;
    const tabs = await chrome.tabs.query({ url: ["*://*.hhaexchange.com/*", "*://hhaexchange.com/*"] });
    for (const tab of tabs) {
      const url = tab.url || tab.pendingUrl || "";
      const isNew = !known.has(tab.id);
      if (shouldIgnoreExistingTab(tab.id)) continue;
      const kind = pageKind(url);
      const reportLike =
        kind === "viewer" ||
        (isNew && looksLikeViewerUrl(url));
      if (!reportLike) continue;

      activeRun.trackedTabIds = Array.from(new Set([...(activeRun.trackedTabIds || []), tab.id]));
      await saveRun();
      await focusTab(tab);
      if (tab.status === "complete" && kind !== "setup" && activeRun.stage !== "waitingDownload") {
        const sentAt = activeRun.exportSentAt?.[tab.id] || 0;
        if (activeRun.exportClickedAt) continue;
        if (exportSentTabs.has(tab.id) && Date.now() - sentAt < 12000) continue;
        exportSentTabs.add(tab.id);
        activeRun.exportSentAt = { ...(activeRun.exportSentAt || {}), [tab.id]: Date.now() };
        activeRun.stage = "exporting";
        await log("View window is on screen. Waiting for the report to finish drawing, then Excel…");
        startHeartbeat();
        try {
          await send(tab.id, { type: "HHA_EXPORT_EXCEL" });
        } catch (error) {
          exportSentTabs.delete(tab.id);
          await log(`Could not reach the report viewer yet (${error.message}). Will retry.`);
        }
      }
    }
    await new Promise((resolve) => setTimeout(resolve, 500));
  }

  if (activeRun && (activeRun.stage === "waitingViewer" || activeRun.stage === "configuring")) {
    const tabs = await chrome.tabs.query({ url: ["*://*.hhaexchange.com/*", "*://hhaexchange.com/*"] });
    const viewer = tabs.find((t) => pageKind(t.url || "") === "viewer" && activeRun.trackedTabIds?.includes(t.id)) ||
      tabs.find((t) => activeRun.trackedTabIds?.includes(t.id) && t.id !== activeRun.rootTabId);
    if (viewer?.id) {
      if (!activeRun.exportClickedAt && !exportSentTabs.has(viewer.id)) {
        exportSentTabs.add(viewer.id);
        activeRun.stage = "exporting";
        await saveRun();
        try { await send(viewer.id, { type: "HHA_EXPORT_EXCEL" }); } catch (_) {}
      }
      return viewer;
    }
    if (activeRun.exportClickedAt || activeRun.exportDispatchedAt || activeRun.downloadId != null) return null;
    let drawing = false;
    if (activeRun.rootTabId) {
      const state = await pageEval(activeRun.rootTabId, "reportViewerState", {});
      drawing = Boolean(state?.hasViewer || state?.rendered || state?.hasExport || state?.overlayLoading || (state?.totalPages || 0) > 0);
    }
    if (drawing) {
      await log("Report is drawing in the open tab. Excel waits until the pages settle.");
      return null;
    }
    await finish(
      false,
      "The View Report window did not open. If Chrome blocked a popup, allow popups for hhaexchange.com and retry."
    );
  }
  return null;
}

async function scheduleNextAlarm() {
  const settings = await getSettings();
  try { await chrome.alarms.clear(ALARM_NAME); } catch (_) {}
  if (!settings.scheduleEnabled) return null;
  const next = nextWeekdayFire(settings.hour, settings.minute, settings.weekdaysOnly);
  await chrome.alarms.create(ALARM_NAME, { when: next.getTime() });
  return next;
}

async function armRunWatch() {
  if (!activeRun) return;
  try {
    await chrome.alarms.create(WATCH_ALARM, { when: Date.now() + 8000 });
  } catch (_) {}
}

async function onRunWatch() {
  if (!activeRun) {
    try { await chrome.alarms.clear(WATCH_ALARM); } catch (_) {}
    return;
  }
  const elapsed = Date.now() - (activeRun.startedAt || Date.now());
  if (elapsed > 10 * 60 * 1000) {
    await finish(false, "The pull timed out after 10 minutes. Leave the View window open until the pages appear, then retry.");
    return;
  }
  await armRunWatch();
  if (activeRun.stage === "waitingDownload") return;
  if (activeRun.exportClickedAt) return;
  if (activeRun.stage === "waitingViewer" || activeRun.stage === "exporting" || activeRun.stage === "configuring") {
    await kickExcelOnViewerTabs();
  }
}

async function nextAlarmInfo() {
  const settings = await getSettings();
  if (!settings.scheduleEnabled) return { enabled: false, nextAt: null, label: "Off" };
  const alarm = await chrome.alarms.get(ALARM_NAME);
  const next = alarm?.scheduledTime ? new Date(alarm.scheduledTime) : nextWeekdayFire(settings.hour, settings.minute, settings.weekdaysOnly);
  const label = `${weekdayName(next)} ${formatClock(next.getHours(), next.getMinutes())}`;
  return { enabled: true, nextAt: next.getTime(), label, settings };
}

async function maybeNotifyMissedPull() {
  const settings = await getSettings();
  if (!settings.scheduleEnabled) return;
  const now = new Date();
  if (settings.weekdaysOnly && (now.getDay() === 0 || now.getDay() === 6)) return;
  const scheduled = new Date(now);
  scheduled.setHours(settings.hour, settings.minute, 0, 0);
  if (now.getTime() < scheduled.getTime() + 60000) return;
  const stored = await chrome.storage.local.get(LAST_KEY);
  const last = stored[LAST_KEY];
  if (last?.success && sameLocalDay(last.completedAt, now)) return;
  if (activeRun) return;
  await notifyUser({
    id: "hha-missed-pull",
    title: "Missed the weekday report pull",
    message: `Chrome wasn’t ready at ${formatClock(settings.hour, settings.minute)}. Click to pull today’s Maryland report now.`,
    buttons: [{ title: "Pull now" }]
  });
}

function statusPayload(extra = {}) {
  return chrome.storage.local.get([RUN_KEY, LAST_KEY, HISTORY_KEY]).then(async (stored) => {
    const alarm = await nextAlarmInfo();
    return {
      ok: true,
      active: stored[RUN_KEY] || activeRun || null,
      last: stored[LAST_KEY] || null,
      history: stored[HISTORY_KEY] || [],
      settings: alarm.settings || await getSettings(),
      schedule: alarm,
      ...extra
    };
  });
}

chrome.runtime.onConnect.addListener((port) => {
  if (port.name !== "hha-automation") return;
  ports.add(port);
  port.onDisconnect.addListener(() => ports.delete(port));
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  (async () => {
    await initialized;
    if (message?.type === "HHA_SLEEP") {
      const ms = Math.max(0, Math.min(Number(message.ms) || 0, 60000));
      await new Promise((resolve) => setTimeout(resolve, ms));
      sendResponse({ ok: true });
      return;
    }

    if (message?.type === "HHA_PAGE_EVAL") {
      const tabId = sender.tab?.id;
      if (!tabId) {
        sendResponse({ ok: false, error: "No tab." });
        return;
      }
      if (!activeRun || (message.runId && message.runId !== activeRun.id) || !activeRun.trackedTabIds?.includes(tabId)) {
        sendResponse({ ok: false, error: "Run is no longer active." });
        return;
      }
      const result = await pageEval(tabId, message.op, message.args, Number.isInteger(message.frameId) ? message.frameId : null);
      sendResponse({ ok: true, result });
      return;
    }

    if (message?.type === "HHA_CLAIM_EXPORT") {
      const tabId = sender.tab?.id;
      const run = activeRun;
      const eligible = run && message.runId === run.id && run.trackedTabIds?.includes(tabId) && run.stage !== "waitingDownload";
      const granted = eligible && (run.exportOwnerTabId == null || (run.exportOwnerTabId === tabId && message.force && run.downloadId == null));
      if (granted) {
        run.exportOwnerTabId = tabId;
        run.exportDispatchedAt = Date.now();
        run.exportOwnerUrl = sender.tab?.url || "";
        await saveRun();
      }
      sendResponse({ ok: true, granted: Boolean(granted) });
      return;
    }

    if (message?.type === "START_HHA_RUN") {
      const result = await startRun({ trigger: "manual", state: message.state || "maryland" });
      sendResponse(result);
      return;
    }

    if (message?.type === "STOP_HHA_RUN") {
      startupGeneration += 1;
      if (activeRun) await finish(false, "Automation stopped by user.");
      await setBadge("");
      sendResponse({ ok: true });
      return;
    }

    if (message?.type === "HHA_LOG") {
      if (activeRun && (!message.runId || message.runId === activeRun.id)) await log(message.message || "Working…");
      sendResponse({ ok: true });
      return;
    }

    if (message?.type === "HHA_ACTION_RESULT") {
      if (!activeRun || (message.runId && message.runId !== activeRun.id)) {
        sendResponse({ ok: true });
        return;
      }
      if (!message.success) {
        await finish(false, message.error || `Automation failed during ${message.action}.`);
        sendResponse({ ok: true });
        return;
      }
      if (message.action === "NAVIGATE") {
        activeRun.stage = "waitingSetup";
        await log("Waiting for the HHA Report Center…");
      } else if (message.action === "GENERATE_REPORT") {
        activeRun.stage = "waitingViewer";
        await log("Ignoring Generate Report. Using View Report instead, then Excel from that tab.");
        startHeartbeat();
      } else if (message.action === "CONFIGURE_AND_VIEW") {
        activeRun.stage = "waitingViewer";
        await log("Dates set to today. Clicked View Report — watching for the report window, then Excel.");
        startHeartbeat();
        watchForViewerTab().catch(() => {});
      } else if (message.action === "EXPORT_EXCEL") {
        if (!activeRun.exportClickedAt) activeRun.exportClickedAt = Date.now();
        if (activeRun.stage !== "waitingDownload") activeRun.stage = "exporting";
        await log("Excel export clicked in the View window. Waiting for one .xlsx file…");
        await startDownloadWatchdog();
      }
      sendResponse({ ok: true });
      return;
    }

    if (message?.type === "GET_HHA_STATUS") {
      sendResponse(await statusPayload());
      return;
    }

    if (message?.type === "SHOW_HHA_DOWNLOAD") {
      const stored = await chrome.storage.local.get([LAST_KEY, HISTORY_KEY]);
      const id = message.downloadId ?? stored[LAST_KEY]?.downloadId;
      const known = stored[LAST_KEY]?.downloadId === id || (stored[HISTORY_KEY] || []).some(row => row.downloadId === id && row.success);
      if (known && Number.isInteger(id)) {
        try { await chrome.downloads.show(id); } catch (_) { await chrome.downloads.showDefaultFolder(); }
      } else { await chrome.downloads.showDefaultFolder(); }
      sendResponse({ ok: true });
      return;
    }

    if (message?.type === "GET_HHA_SETTINGS") {
      sendResponse({ ok: true, settings: await getSettings(), schedule: await nextAlarmInfo() });
      return;
    }

    if (message?.type === "SET_HHA_SETTINGS") {
      const settings = await saveSettings(message.settings || {});
      sendResponse({ ok: true, settings, schedule: await nextAlarmInfo() });
      return;
    }

    if (message?.type === "HHA_PING") {
      sendResponse({ ok: true });
      return;
    }
  })().catch((error) => {
    try { sendResponse({ ok: false, error: error.message }); } catch (_) {}
  });
  return true;
});

function suggestedReportFilename(item) {
  const pending = renameState?.enabled ? renameState : null;
  const folder = String(pending?.folder || "").replace(/^\/+|\/+$/g, "");
  const base = pending?.base || `Report of ${filenameDate()}`;
  return `${folder ? folder + "/" : ""}${base}.${extensionFromDownload(item)}`;
}

chrome.downloads.onDeterminingFilename.addListener((item, suggest) => {
  // Suggest immediately. Waiting on storage here leaves the file spinning
  // in Chrome's download shelf until the pull is reported as failed.
  try {
    if (!isRunDownload(item) || (acceptedDownloadId != null && acceptedDownloadId !== item.id)) {
      suggest();
      return;
    }
    suggest({ filename: suggestedReportFilename(item), conflictAction: "uniquify" });
    queueDownload(async () => { await acceptDownload(item); }).catch(() => {});
  } catch (_) {
    try { suggest(); } catch (__) {}
  }
});

let downloadEvents = Promise.resolve();
function queueDownload(task) {
  const next = downloadEvents.then(async () => { await initialized; return task(); });
  downloadEvents = next.catch(() => {});
  return next;
}

function isRunDownload(item) {
  if (!activeRun || runSucceeded) return false;
  if (!activeRun.exportDispatchedAt && !activeRun.exportClickedAt && item.id !== activeRun.downloadId) return false;
  // Exports may originate in a child frame, and Referrer-Policy may shorten
  // its URL to the origin. Match the portal origin, not the top-level path.
  if (item.referrer && !isHhaUrl(item.referrer) && !isHhaUrl(item.url || "")) return false;
  const stageOk = ["configuring", "waitingViewer", "exporting", "waitingDownload"].includes(activeRun.stage);
  if (!stageOk) return false;
  if (activeRun.stage === "configuring" && !activeRun.exportDispatchedAt && !activeRun.exportClickedAt && item.id !== activeRun.downloadId) return false;
  if (item.startTime && new Date(item.startTime).getTime() < activeRun.startedAt) return false;
  return downloadLooksLikeReport(item);
}

async function acceptDownload(item) {
  if (!activeRun || (acceptedDownloadId != null && acceptedDownloadId !== item.id)) return;
  acceptedDownloadId = item.id;
  watchedDownloads.set(item.id, { ...watchedDownloads.get(item.id), ...item });
  activeRun.stage = "waitingDownload";
  activeRun.downloadId = item.id;
  stopHeartbeat();
  await log("Saving the Excel file to Downloads…");
  await startDownloadWatchdog();
}

chrome.downloads.onCreated.addListener(item => queueDownload(async () => {
  if (!isRunDownload(item)) return;
  // Leave other downloads alone. Export dispatch is locked before clicking.
  if (acceptedDownloadId != null && acceptedDownloadId !== item.id) return;
  await acceptDownload(item);
  if (item.state === "complete") await onReportDownloaded(item);
}));

chrome.downloads.onChanged.addListener(delta => queueDownload(async () => {
  if (!activeRun || runSucceeded) return;
  let tracked = delta.id === activeRun.downloadId || delta.id === acceptedDownloadId;
  if (!tracked) {
    if (delta.state?.current !== "complete" && !delta.filename && !delta.mime) return;
    const found = (await chrome.downloads.search({ id: delta.id }).catch(() => []))[0];
    if (!found || !isRunDownload(found)) return;
    await acceptDownload(found);
    if (found.state === "complete" || delta.state?.current === "complete") {
      await onReportDownloaded(found);
      return;
    }
    tracked = true;
  }
  if (!tracked) return;
  if (delta.filename?.current) {
    const prev = watchedDownloads.get(delta.id) || { id: delta.id };
    watchedDownloads.set(delta.id, { ...prev, filename: delta.filename.current });
  }
  if (delta.state?.current === "complete") {
    const [actual] = await chrome.downloads.search({ id: delta.id });
    const item = actual || watchedDownloads.get(delta.id) || { id: delta.id, filename: delta.filename?.current };
    watchedDownloads.delete(delta.id);
    if (acceptedDownloadId && delta.id !== acceptedDownloadId) return;
    await onReportDownloaded(item);
  } else if (delta.state?.current === "interrupted") {
    watchedDownloads.delete(delta.id);
    if (acceptedDownloadId && delta.id !== acceptedDownloadId) return;
    if (activeRun) {
      acceptedDownloadId = null;
      await finish(false, "The Excel download was interrupted. Check Chrome’s download shelf and retry.");
    }
  }
}));

chrome.tabs.onCreated.addListener(async (tab) => {
  if (!activeRun) return;
  const openerTracked = tab.openerTabId && activeRun.trackedTabIds?.includes(tab.openerTabId);
  const recentHhaPopup = isHhaUrl(tab.pendingUrl || tab.url || "") && Date.now() - activeRun.startedAt < 120000;
  if (openerTracked || recentHhaPopup) {
    activeRun.trackedTabIds = Array.from(new Set([...(activeRun.trackedTabIds || []), tab.id]));
    await saveRun();
    try { await chrome.tabs.update(tab.id, { autoDiscardable: false }); } catch (_) {}
    if (activeRun.stage === "waitingViewer" || activeRun.stage === "configuring" || activeRun.stage === "exporting") {
      await focusTab(tab);
      await log("View Report window opened. You should see the report loading there.");
    }
  }
});

chrome.windows.onCreated.addListener((win) => {
  if (!activeRun?.keepInBackground) return;
  setTimeout(() => keepWindowInBackground(win), 80);
});

chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
  const url = tab.url || changeInfo.url || "";
  if (url) await rememberPortal(url);

  if (!activeRun) return;
  if (changeInfo.status !== "complete" && !changeInfo.url) return;

  const tracked = activeRun.trackedTabIds?.includes(tabId);
  const recentReportTab = isHhaUrl(url) && /report/i.test(url) && Date.now() - activeRun.startedAt < 900000;
  if (shouldIgnoreExistingTab(tabId)) {
    const kindNow = pageKind(url);
    const navigatedToViewer = Boolean(changeInfo.url) && kindNow === "viewer";
    const finishedAfterView = changeInfo.status === "complete" && kindNow === "viewer" &&
      (activeRun.stage === "waitingViewer" || activeRun.stage === "exporting");
    if (navigatedToViewer || finishedAfterView) await adoptViewerTab(tabId);
    else return;
  }
  if (changeInfo.status === "complete") exportSentTabs.delete(tabId);
  if (!activeRun.trackedTabIds?.includes(tabId) && !recentReportTab) return;

  if (recentReportTab && !tracked) {
    activeRun.trackedTabIds = Array.from(new Set([...(activeRun.trackedTabIds || []), tabId]));
    await saveRun();
  }

  if (pageKind(url) === "viewer" && changeInfo.status !== "complete") return;
  await routeTab(tabId, url);
});

chrome.tabs.onRemoved.addListener(async (tabId) => {
  if (!activeRun) return;
  if (activeRun.trackedTabIds?.includes(tabId)) {
    activeRun.trackedTabIds = activeRun.trackedTabIds.filter((id) => id !== tabId);
    await saveRun();
  }
});

chrome.alarms.onAlarm.addListener(async (alarm) => {
  await initialized;
  if (alarm.name === WATCH_ALARM) {
    await onRunWatch();
    return;
  }
  if (alarm.name !== ALARM_NAME) return;
  await scheduleNextAlarm();
  const settings = await getSettings();
  const now = new Date();
  if (!settings.scheduleEnabled) return;
  if (settings.weekdaysOnly && (now.getDay() === 0 || now.getDay() === 6)) return;
  if (activeRun) {
    await log("Scheduled pull skipped — a run is already in progress.");
    return;
  }
  const stored = await chrome.storage.local.get(LAST_KEY);
  const last = stored[LAST_KEY];
  if (last?.success && sameLocalDay(last.completedAt, now) && now.getTime() - last.completedAt < 10 * 60 * 1000) {
    return;
  }
  const result = await startRun({ trigger: "schedule", state: "maryland" });
  if (!result.ok) {
    await notifyUser({
      id: "hha-schedule-failed",
      title: "Couldn’t pull the scheduled report",
      message: result.error || "Open HHAeXchange, stay logged in, and I’ll retry from the popup.",
      buttons: [{ title: "Open popup help" }]
    });
  }
});

chrome.notifications.onButtonClicked.addListener(async (notificationId, buttonIndex) => {
  if (notificationId === "hha-report-ready") {
    await showLastDownload();
    return;
  }
  if (notificationId === "hha-need-login" || notificationId === "hha-schedule-failed") {
    const tab = await findHhaTab();
    if (tab?.id) {
      try {
        await chrome.tabs.update(tab.id, { active: true });
        if (tab.windowId) await chrome.windows.update(tab.windowId, { focused: true });
      } catch (_) {}
    }
    return;
  }
  if (notificationId === "hha-missed-pull" && buttonIndex === 0) {
    await startRun({ trigger: "manual", state: "maryland" });
  }
});

chrome.notifications.onClicked.addListener(async (notificationId) => {
  if (notificationId === "hha-report-ready") {
    await showLastDownload();
    return;
  }
  const tab = await findHhaTab();
  if (tab?.id) {
    try {
      await chrome.tabs.update(tab.id, { active: true });
      if (tab.windowId) await chrome.windows.update(tab.windowId, { focused: true });
    } catch (_) {}
  }
});

async function showLastDownload() {
  const stored = await chrome.storage.local.get(LAST_KEY);
  const id = stored[LAST_KEY]?.downloadId;
  try {
    if (Number.isInteger(id)) await chrome.downloads.show(id);
    else await chrome.downloads.showDefaultFolder();
  } catch (_) { try { await chrome.downloads.showDefaultFolder(); } catch (_) {} }
}

async function boot() {
  try {
    const stored = await chrome.storage.local.get([RUN_KEY, RENAME_KEY]);
    activeRun = stored[RUN_KEY] || null;
    acceptedDownloadId = activeRun?.downloadId ?? null;
    exportRetryCount = activeRun?.exportRetryCount || 0;
    if (stored[RENAME_KEY]?.enabled) renameState = stored[RENAME_KEY];
    if (activeRun && Date.now() - (activeRun.startedAt || 0) > 20 * 60 * 1000) {
      await finish(false, "Previous pull was interrupted (Chrome restarted). Try again.");
    } else if (activeRun) {
      await armRunWatch();
      startHeartbeat();
      if (activeRun.downloadId != null) {
        const [item] = await chrome.downloads.search({ id: activeRun.downloadId });
        if (item?.state === "complete") await onReportDownloaded(item);
        else if (!item || item.state === "interrupted") await finish(false, "The download was interrupted. Pull the report again.");
        else { watchedDownloads.set(item.id, item); await startDownloadWatchdog(); }
      } else if (activeRun.exportClickedAt) {
        await startDownloadWatchdog();
      }
      if (activeRun && !activeRun.exportClickedAt && (activeRun.stage === "waitingViewer" || activeRun.stage === "exporting" || activeRun.stage === "configuring")) {
        kickExcelOnViewerTabs().catch(() => {});
      }
    }
    await getSettings();
    await scheduleNextAlarm();
  } catch (_) {}
}

chrome.runtime.onInstalled.addListener(async () => {
  await saveSettings(await getSettings());
  await setBadge("");
});

chrome.runtime.onStartup.addListener(async () => {
  await scheduleNextAlarm();
  await maybeNotifyMissedPull();
});

const initialized = boot();
