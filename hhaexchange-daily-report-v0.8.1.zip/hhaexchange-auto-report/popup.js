/* global chrome */
const $ = id => document.getElementById(id);
let snapshot = null;
let loading = false;
let refreshAgain = false;
let folderDirty = false;
let settingsChain = Promise.resolve();
let lastHistory = "";
const pad = n => String(n).padStart(2, "0");
const duration = ms => { const s = Math.max(0, Math.floor(ms / 1000)); return s < 60 ? `${s}s` : `${Math.floor(s / 60)}m ${pad(s % 60)}s`; };
const filename = () => { const d = new Date(); return `Report of ${pad(d.getMonth() + 1)}-${pad(d.getDate())}-${d.getFullYear()}.xlsx`; };
async function send(message) {
  const result = await chrome.runtime.sendMessage(message);
  if (!result?.ok) throw new Error(result?.error || "The extension did not respond. Reload it and try again.");
  return result;
}
function showPanel(id) {
  for (const panel of document.querySelectorAll(".panel")) panel.hidden = panel.id !== id;
  for (const tab of document.querySelectorAll(".tab")) {
    const selected = tab.dataset.panel === id;
    tab.classList.toggle("is-selected", selected);
    tab.setAttribute("aria-pressed", String(selected));
  }
}
function busy(value) {
  $("runButton").disabled = value;
  $("stopButton").hidden = !value;
  $("runLabel").textContent = value ? "Taking care of your report…" : "Pull today’s report";
}
function stepFromStage(stage) {
  return ({navigating:1,waitingSetup:1,configuring:2,waitingViewer:3,waitingGenerate:3,exporting:3,waitingDownload:4,complete:5})[stage] || 0;
}
function renderSettings(settings, schedule) {
  $("scheduleToggle").checked = settings.scheduleEnabled;
  $("notifyToggle").checked = settings.notifyOnComplete !== false;
  $("hourSelect").value = String(((settings.hour + 11) % 12) + 1);
  $("minuteSelect").value = String(settings.minute);
  $("meridiemSelect").value = settings.hour >= 12 ? "pm" : "am";
  for (const id of ["hourSelect", "minuteSelect", "meridiemSelect"]) $(id).disabled = !settings.scheduleEnabled;
  if (!folderDirty) $("folderInput").value = settings.downloadFolder ?? "HHA Reports";
  $("saveLocation").textContent = `Downloads${settings.downloadFolder ? " / " + settings.downloadFolder : ""}`;
  $("nextRun").textContent = settings.scheduleEnabled ? `Next auto-pull · ${schedule?.label || "Scheduled"}` : "Auto-pull is off · Set a schedule";
}
function renderHistory(history) {
  const signature = JSON.stringify(history);
  if (signature === lastHistory) return;
  lastHistory = signature;
  $("historyCount").textContent = String(history.length);
  $("emptyHistory").hidden = history.length > 0;
  $("historyList").replaceChildren();
  for (const row of history) {
    const card = document.createElement("article"); card.className = "history-row";
    const icon = document.createElement("span"); icon.className = `history-icon${row.success ? "" : " error"}`; icon.textContent = row.success ? "✓" : "!";
    const copy = document.createElement("div"); copy.className = "history-copy";
    const title = document.createElement("h2"); title.textContent = row.success ? row.savedAs || "Report saved" : "Run needs attention";
    const detail = document.createElement("p"); detail.textContent = `${new Date(row.completedAt).toLocaleString([], {month:"short",day:"numeric",hour:"numeric",minute:"2-digit"})} · ${duration(row.durationMs || 0)} · ${row.trigger === "schedule" ? "Scheduled" : "Manual"}`;
    copy.append(title, detail);
    if (!row.success) { const reason = document.createElement("p"); reason.className = "failure"; reason.textContent = row.statusMessage; copy.append(reason); }
    card.append(icon, copy);
    if (row.success && Number.isInteger(row.downloadId)) {
      const button = document.createElement("button"); button.type = "button"; button.className = "icon-button"; button.textContent = "↗"; button.setAttribute("aria-label", `Show ${row.savedAs || "report"} in folder`);
      button.addEventListener("click", () => send({type:"SHOW_HHA_DOWNLOAD",downloadId:row.downloadId}).catch(showError)); card.append(button);
    }
    $("historyList").append(card);
  }
}
function paint(res) {
  snapshot = res;
  const active = res.active, last = res.last;
  busy(Boolean(active));
  document.body.dataset.status = active ? "running" : last && !last.success ? "error" : last?.success ? "success" : "ready";
  $("statusTitle").textContent = active ? ({navigating:"Connecting to your portal",waitingSetup:"Opening the report",configuring:"Setting today’s dates",waitingViewer:"Building your report",exporting:"Preparing Excel",waitingDownload:"Saving your file"})[active.stage] || "Working on your report" : last?.success ? "Saved. You’re all set." : last ? "Let’s try that again" : "Ready when you are";
  $("statusMessage").textContent = active?.statusMessage || last?.statusMessage || "Sign in to HHAeXchange, then leave the report to us.";
  $("fileChip").textContent = active?.targetFilename || (last?.success ? last.savedAs : filename());
  $("showFileButton").hidden = !last?.success || !Number.isInteger(last.downloadId);
  const step = active ? stepFromStage(active.stage) : last?.success ? 5 : 0;
  for (const li of $("stepList").children) { const n = Number(li.dataset.step); li.classList.toggle("is-current", step === n); li.classList.toggle("is-done", step > n); }
  renderSettings(res.settings, res.schedule); renderHistory(res.history || []); updateElapsed();
}
function updateElapsed() {
  const run = snapshot?.active || snapshot?.last;
  $("elapsed").textContent = run?.startedAt ? duration((run.completedAt || Date.now()) - run.startedAt) : "—";
}
function showError(error) { $("statusTitle").textContent = "Needs attention"; $("statusMessage").textContent = error.message; document.body.dataset.status = "error"; }
async function refresh() {
  if (loading) { refreshAgain = true; return; }
  loading = true;
  try { paint(await send({type:"GET_HHA_STATUS"})); } catch (error) { busy(false); showError(error); }
  finally { loading = false; if (refreshAgain) { refreshAgain = false; refresh(); } }
}
function saveSettings(settings) {
  settingsChain = settingsChain.catch(() => {}).then(async () => {
    try {
      const result = await send({type:"SET_HHA_SETTINGS",settings});
      if ("downloadFolder" in settings) folderDirty = false;
      renderSettings(result.settings, result.schedule);
      $("settingsFeedback").textContent = "Preferences saved."; $("settingsFeedback").classList.remove("error");
    } catch (error) { $("settingsFeedback").textContent = error.message; $("settingsFeedback").classList.add("error"); }
  });
}
for (const tab of document.querySelectorAll(".tab")) tab.addEventListener("click", () => showPanel(tab.dataset.panel));
$("scheduleShortcut").addEventListener("click", () => showPanel("settingsPanel"));
for (let hour = 1; hour <= 12; hour++) $("hourSelect").add(new Option(String(hour), String(hour)));
for (let minute = 0; minute < 60; minute++) $("minuteSelect").add(new Option(pad(minute), String(minute)));
$("scheduleToggle").addEventListener("change", () => saveSettings({scheduleEnabled:$("scheduleToggle").checked}));
$("notifyToggle").addEventListener("change", () => saveSettings({notifyOnComplete:$("notifyToggle").checked}));
for (const id of ["hourSelect", "minuteSelect", "meridiemSelect"]) $(id).addEventListener("change", () => saveSettings({hour:Number($("hourSelect").value) % 12 + ($("meridiemSelect").value === "pm" ? 12 : 0),minute:Number($("minuteSelect").value)}));
$("folderInput").addEventListener("input", () => { folderDirty = true; });
$("saveFolderButton").addEventListener("click", () => saveSettings({downloadFolder:$("folderInput").value}));
$("folderInput").addEventListener("keydown", event => { if (event.key === "Enter") saveSettings({downloadFolder:$("folderInput").value}); });
$("runButton").addEventListener("click", async () => {
  busy(true); $("statusTitle").textContent = "Connecting…"; $("statusMessage").textContent = "Finding your HHAeXchange session.";
  try { await send({type:"START_HHA_RUN",state:"maryland"}); await refresh(); } catch (error) { busy(false); showError(error); }
});
$("stopButton").addEventListener("click", async () => { try { await send({type:"STOP_HHA_RUN"}); await refresh(); } catch (error) { showError(error); } });
$("showFileButton").addEventListener("click", () => send({type:"SHOW_HHA_DOWNLOAD"}).catch(showError));
$("downloadSettingsButton").addEventListener("click", () => chrome.tabs.create({url:"chrome://settings/downloads"}));
$("todayLabel").textContent = new Date().toLocaleDateString([], {weekday:"short",month:"short",day:"numeric"}).toUpperCase();
$("fileChip").textContent = filename();
chrome.storage.onChanged.addListener((changes, area) => { if (area === "local" && ["hhaActiveRun","hhaLastRun","hhaRunHistory","hhaSettings"].some(key => key in changes)) refresh(); });
refresh();
setInterval(updateElapsed, 1000);
